@extends('site.layout.base.basico')
@section('Titulo','Conteudo')
@section('conteudo')
    <div class="containers">
        Conteudo em desenvolvimento.
    </div>
@endsection
