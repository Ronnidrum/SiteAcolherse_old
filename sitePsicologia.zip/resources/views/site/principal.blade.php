@extends('site.layout.base.basico')

@section('conteudo')



        <div class="containers" >

                @include('site.layout.parciais._carrossel')

                @include('site.layout.parciais._menuMobile')

        </div>



@endsection
