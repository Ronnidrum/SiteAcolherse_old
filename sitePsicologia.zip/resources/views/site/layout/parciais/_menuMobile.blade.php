<div id="mobile" class = 'cmenumobile'>
    <div   class="menu-mobile">
        <ul>
            <li><a href={{route('home')}}>Home</a></li>
            <li><a href={{route('psicoterapia')}}>Psicoterapia</a></li>
            <li><a href={{route('neuropsicologia')}}>Neuropsicologia</a></li>
            <li><a href={{route('conteudo')}}>Conteúdo</a></li>
            <li><a href={{route('contato')}}>Contato</a></li>
            <li><a href={{route('sobre')}}>Sobre</a></li>
        </ul>
    </div>
</div>
