<footer class="footer">
    <div id="footer">
        <div class="mail"><img src="../image/icone/mensagem.gif" alt="">
             psicologiaacolherse@gmail.com <br>
             Contato via email.
        </div>

    </div>
    <div id="social"  class="col item social">
        <a href="https://www.facebook.com/psicologiaacolherse/">
            <i class="icon ion-social-facebook"></i>
        </a>
        <a href="https://instagram.com/psicologiaacolherse?igshid=YmMyMTA2M2Y="><i class="icon ion-social-instagram"></i>
        </a>
    </div>

</footer>
