<header class="cabecalho">
     <nav class="menu">
         <ul>
             <li><a href={{route('home')}}>Home</a></li>
             <li><a href={{route('psicoterapia')}}>Psicoterapia</a></li>
             <li><a href={{route('neuropsicologia')}}>Neuropsicologia</a></li>
             <li><a href={{route('conteudo')}}>Conteúdo</a></li>
             <li><a href={{route('contato')}}>Contato</a></li>
             <li><a href={{route('sobre')}}>Sobre</a></li>
         </ul>
     </nav>
      <span id = "btn" class="btn-menu">
             <span></span>
             <span></span>
             <span></span>
     </span>

 </header>
