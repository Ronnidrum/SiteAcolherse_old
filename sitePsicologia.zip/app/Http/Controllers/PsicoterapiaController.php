<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PsicoterapiaController extends Controller
{
    //
    public function index(){
        return view('site.psicoterapia');
    }
}
