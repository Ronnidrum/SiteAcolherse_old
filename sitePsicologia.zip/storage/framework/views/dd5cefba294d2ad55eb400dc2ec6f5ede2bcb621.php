<?php $__env->startSection('Titulo', 'Sobre'); ?>
<?php $__env->startSection('conteudo'); ?>
    <div class="contexto sobre">
        <div class="texto">
            <p><h3>
                O Acolher-se é um projeto idealizado por psicólogas para atendimentos individuais e em grupo, com o intuito
                de proporcionar um espaço de acolhimento para que, ao se sentir acolhida, a pessoa possa acolher a si mesma
                com seus pensamentos e sentimentos. O projeto visa reconhecer o indivíduo em suas singularidades, através da
                relação terapêutica, propiciando conhecimento sobre o próprio funcionamento emocional, levando-o a
                aceitar-se e acolher-se.</h3>

            </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layout.base.basico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ronniery\Documents\projetos\code\sitePsicologia\resources\views/site/sobre.blade.php ENDPATH**/ ?>