<header class="cabecalho">
    <!-- <div class="logo">
         <img src="img/LOGO SEM FUNDO WEEB.png" alt="">
     </div>-->
     <nav class="menu">
         <ul>
             <li><a href="#Home">Home</a></li>
             <li><a href="#Psicoterapia">Psicoterapia</a></li>
             <li><a href="#Neuropsicologia">Neuropsicologia</a></li>
             <li><a href="#Conteúdo">Conteúdo</a></li>
             <li><a href=<?php echo e(route('contato')); ?>>Contato</a></li>
             <li><a href="#Sobre">Sobre</a></li>
         </ul>
     </nav>
      <span id = "btn" class="btn-menu">
             <span></span>
             <span></span>
             <span></span>
     </span>
     <br><br><br>
     <div id="mobile"  class="menu-mobile">
        <ul>
            <li><a href="#Home">Home</a></li>
            <li><a href="#Psicoterapia">Psicoterapia</a></li>
            <li><a href="#Neuropsicologia">Neuropsicologia</a></li>
            <li><a href="#Conteúdo">Conteúdo</a></li>
            <li><a href="#Contato">Contato</a></li>
            <li><a href="#Sobre">Sobre</a></li>
        </ul>
    </div>
 </header>
<?php /**PATH C:\Users\Ronniery\Documents\projetos\code\sitePsicologia\resources\views/site/layout/base/_menu.blade.php ENDPATH**/ ?>