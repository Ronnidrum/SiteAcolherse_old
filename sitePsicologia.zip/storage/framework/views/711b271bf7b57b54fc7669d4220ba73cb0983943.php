<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Contoto</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon.ico')); ?>">
    <script type="text/javascript" src="assets/js/jquery.js"></script>
    <link rel="stylesheet" type="text/css"  href="assets/css/style.css" >

    <!-- CSS here -->

</head>
<body>
    <?php echo $__env->yieldContent('conteudo'); ?>
</body>
</html>
<?php /**PATH C:\Users\Ronniery\Documents\projetos\code\sitePsicologia\resources\views/site/layout/basico.blade.php ENDPATH**/ ?>