<?php $__env->startSection('Titulo','Conteudo'); ?>
<?php $__env->startSection('conteudo'); ?>
    <div class="containers">
        Conteudo em desenvolvimento.
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layout.base.basico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ronniery\Documents\projetos\code\sitePsicologia\resources\views/site/conteudo.blade.php ENDPATH**/ ?>