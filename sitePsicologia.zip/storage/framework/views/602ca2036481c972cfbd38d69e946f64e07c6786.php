<div id="mobile" class = 'cmenumobile'>
    <div   class="menu-mobile">
        <ul>
            <li><a href=<?php echo e(route('home')); ?>>Home</a></li>
            <li><a href=<?php echo e(route('psicoterapia')); ?>>Psicoterapia</a></li>
            <li><a href=<?php echo e(route('neuropsicologia')); ?>>Neuropsicologia</a></li>
            <li><a href=<?php echo e(route('conteudo')); ?>>Conteúdo</a></li>
            <li><a href=<?php echo e(route('contato')); ?>>Contato</a></li>
            <li><a href=<?php echo e(route('sobre')); ?>>Sobre</a></li>
        </ul>
    </div>
</div>
<?php /**PATH C:\Users\Ronniery\Documents\projetos\code\sitePsicologia\resources\views/site/layout/parciais/_menuMobile.blade.php ENDPATH**/ ?>