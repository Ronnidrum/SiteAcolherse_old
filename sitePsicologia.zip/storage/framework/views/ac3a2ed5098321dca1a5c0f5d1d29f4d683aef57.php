<?php $__env->startSection('conteudo'); ?>

    <section class = "section">
        <div class="containers" id="containers">

                <?php echo $__env->make('site.layout.parciais._carrossel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->make('site.layout.parciais._menuMobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </section>
    <?php echo $__env->make('site.layout.parciais._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layout.base.basico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ronniery\Documents\projetos\code\sitePsicologia\resources\views/site/principal.blade.php ENDPATH**/ ?>